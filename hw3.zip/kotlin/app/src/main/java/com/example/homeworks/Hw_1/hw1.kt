package com.example.homeworks.Hw_1

fun main() {

    var sehir = "Eskişehir"
    val ulke = "Türkiye"
    var telefon = "0555 555 55 55"
    val postaKodu = "34000"
    var email = "example@gmail.com"
    val meslek = "Doktor"
    var stokMiktari = 155
    val musteriAdi = "Ayşe KAYA"
    var bakiye = 1200.75
    val dogumGunu = "1995-04-15"
    var maas = 30000
    var medeniDurum = "Bekar"
    var urunYorum = "Çok kaliteli ürün, mükemmel"
    val odemeTarihi = "2025-04-30"
    var odeme = 500.0
    var siparisAdeti = 3
    var arabaModeli = "Tesla"
    var kitapAdi = "Uğultulu Tepeler"
    val yayinlamaTarihi = "2020-09-15"
    var indirimMiktari = 25.5
    var odaSayisi = 2
    var enlem = 41.0082
    var boylam = 28.9784
    val urunAdi = "Laptop"
    var yemekFiyati = 75.0
    val marka = "Sony"
    var muzikAdi = "Affet"
    var videoSuresi = 215
    var urunPuani = 4.8
    val resimAdi = "foto.jpg"
    var dosyaFormati = "jpg"
    var renk = "Mavi"
    val renkKodu = "#0000FF"
    var telefonModeli = "iPhone 14"
    var ekranBoyutu = 6.1
    var agirlik = 1.2
    val ulusalGun = "Cumhuriyet Bayramı"
    var tatilGunu = "1 Mayıs"
    var rezervasyonTarihi = "2025-07-20"
    val sokakAdi = "Atatürk Caddesi"
    var otobusHatti = "34AS"
    var kalanDakika = 12
    var takipKodu = "ABC123XYZ"
    var kuponSuresi = 30 // gün
    var kuponKodu = "INDIRIM30"
    val faturaAdresi = "Beyoğlu, İstanbul"

    // Print
    println("Şehir: $sehir")
    println("Ülke: $ulke")
    println("Telefon: $telefon")
    println("Posta Kodu: $postaKodu")
    println("Email: $email")
    println("Meslek: $meslek")
    println("Stok Miktarı: $stokMiktari")
    println("Müşteri Adı: $musteriAdi")
    println("Bakiye: $bakiye")
    println("Doğum Günü: $dogumGunu")
    println("Maaş: $maas")
    println("Medeni Durum: $medeniDurum")
    println("Ürün Yorum: $urunYorum")
    println("Ödeme Tarihi: $odemeTarihi")
    println("Ödeme: $odeme")
    println("Sipariş Adeti: $siparisAdeti")
    println("Araba Modeli: $arabaModeli")
    println("Kitap Adı: $kitapAdi")
    println("Yayınlama Tarihi: $yayinlamaTarihi")
    println("İndirim Miktarı: $indirimMiktari")
    println("Oda Sayısı: $odaSayisi")
    println("Enlem: $enlem")
    println("Boylam: $boylam")
    println("Ürün Adı: $urunAdi")
    println("Yemek Fiyatı: $yemekFiyati")
    println("Marka: $marka")
    println("Müzik Adı: $muzikAdi")
    println("Video Süresi: $videoSuresi saniye")
    println("Ürün Puanı: $urunPuani")
    println("Resim Adı: $resimAdi")
    println("Dosya Formatı: $dosyaFormati")
    println("Renk: $renk")
    println("Renk Kodu: $renkKodu")
    println("Telefon Modeli: $telefonModeli")
    println("Ekran Boyutu: $ekranBoyutu inç")
    println("Ağırlık: $agirlik kg")
    println("Ulusal Gün: $ulusalGun")
    println("Tatil Günü: $tatilGunu")
    println("Rezervasyon Tarihi: $rezervasyonTarihi")
    println("Sokak Adı: $sokakAdi")
    println("Otobüs Hattı: $otobusHatti")
    println("Kalan Dakika: $kalanDakika")
    println("Takip Kodu: $takipKodu")
    println("Kupon Süresi: $kuponSuresi gün")
    println("Kupon Kodu: $kuponKodu")
    println("Fatura Adresi: $faturaAdresi")
}
