package com.example.yemekler.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.yemekler.model.Yemek
import com.example.yemekler.model.SepetYemek
import com.example.yemekler.repository.YemekRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class YemekViewModel : ViewModel() {

    private val repo = YemekRepository()

    val yemeklerListesi = MutableLiveData<List<Yemek>>()
    val sepetYemeklerListesi = MutableLiveData<List<SepetYemek>>()

    fun yemekleriYukle() {
        repo.tumYemekleriGetir().enqueue(object : Callback<com.example.yemekler.model.YemeklerResponse> {
            override fun onResponse(
                call: Call<com.example.yemekler.model.YemeklerResponse>,
                response: Response<com.example.yemekler.model.YemeklerResponse>
            ) {
                if (response.isSuccessful) {
                    yemeklerListesi.value = response.body()?.yemekler ?: emptyList()
                    println("Yemekler geldi: ${yemeklerListesi.value?.size}")
                } else {
                    println("Response başarısız: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<com.example.yemekler.model.YemeklerResponse>, t: Throwable) {
                println("API çağrısı başarısız: ${t.message}")
            }
        })
    }


    fun sepetiYukle(kullanici_adi: String) {
        repo.sepettekiYemekleriGetir(kullanici_adi).enqueue(object : Callback<com.example.yemekler.model.SepetYemeklerResponse> {
            override fun onResponse(
                call: Call<com.example.yemekler.model.SepetYemeklerResponse>,
                response: Response<com.example.yemekler.model.SepetYemeklerResponse>
            ) {
                if (response.isSuccessful) {
                    sepetYemeklerListesi.value = response.body()?.sepet_yemekler ?: emptyList()
                }
            }

            override fun onFailure(call: Call<com.example.yemekler.model.SepetYemeklerResponse>, t: Throwable) {
                // Hata yönetimi ekleyebilirsin
            }
        })
    }

    fun sepeteEkle(
        yemek_adi: String,
        yemek_resim_adi: String,
        yemek_fiyat: String,
        yemek_siparis_adet: Int,
        kullanici_adi: String,
        onSuccess: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        repo.sepeteYemekEkle(yemek_adi, yemek_resim_adi, yemek_fiyat, yemek_siparis_adet, kullanici_adi).enqueue(object : retrofit2.Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    onSuccess()
                } else {
                    onError(Throwable("Sepete eklenirken hata oluştu"))
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                onError(t)
            }
        })
    }

    fun sepettenSil(
        sepet_yemek_id: Int,
        kullanici_adi: String,
        onSuccess: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        repo.sepettenYemekSil(sepet_yemek_id, kullanici_adi).enqueue(object : retrofit2.Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    onSuccess()
                } else {
                    onError(Throwable("Sepetten silinirken hata oluştu"))
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                onError(t)
            }
        })
    }
}
