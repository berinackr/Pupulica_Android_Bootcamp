package com.example.yemekler.view

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.yemekler.databinding.ActivityMainBinding
import com.example.yemekler.view.adapter.YemekAdapter
import com.example.yemekler.viewmodel.YemekViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val yemekViewModel: YemekViewModel by viewModels()
    private lateinit var adapter: YemekAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = YemekAdapter()
        binding.recyclerView.layoutManager = GridLayoutManager(this, 2)

        binding.recyclerView.adapter = adapter

        // Buraya tıklama dinleyicisini ekliyoruz
        adapter.setOnItemClickListener { secilenYemek ->
            val intent = Intent(this, YemekDetayActivity::class.java)
            intent.putExtra("yemek_adi", secilenYemek.yemek_adi)
            intent.putExtra("yemek_fiyat", secilenYemek.yemek_fiyat)
            intent.putExtra("yemek_resim_adi", secilenYemek.yemek_resim_adi)
            startActivity(intent)
        }


        yemekViewModel.yemeklerListesi.observe(this) { yemekler ->
            adapter.submitList(yemekler)
        }

        yemekViewModel.yemekleriYukle()
    }
}
