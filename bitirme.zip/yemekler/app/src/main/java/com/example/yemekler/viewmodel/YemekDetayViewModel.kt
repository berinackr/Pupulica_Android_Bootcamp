package com.example.yemekler.viewmodel

import androidx.lifecycle.ViewModel
import com.example.yemekler.model.Yemek

class YemekDetayViewModel : ViewModel() {

    companion object {
        private val sepetListesi = mutableListOf<Yemek>()
    }

    fun sepeteEkle(yeniYemek: Yemek, adet: Int) {
        val mevcutYemek = sepetListesi.find { it.yemek_adi == yeniYemek.yemek_adi }

        if (mevcutYemek != null) {
            mevcutYemek.yemek_siparis_adet += adet
        } else {
            yeniYemek.yemek_siparis_adet = adet
            sepetListesi.add(yeniYemek)
        }
    }

    fun sepetiGetir(): List<Yemek> = sepetListesi
}
