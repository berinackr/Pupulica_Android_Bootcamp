package com.example.yemekler.view.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.yemekler.databinding.YemekItemBinding
import com.example.yemekler.model.Yemek
import com.bumptech.glide.Glide

class YemekAdapter : ListAdapter<Yemek, YemekAdapter.YemekViewHolder>(DiffCallback) {

    private var onItemClickListener: ((Yemek) -> Unit)? = null

    fun setOnItemClickListener(listener: (Yemek) -> Unit) {
        onItemClickListener = listener
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Yemek>() {
        override fun areItemsTheSame(oldItem: Yemek, newItem: Yemek): Boolean {
            return oldItem.yemek_id == newItem.yemek_id
        }

        override fun areContentsTheSame(oldItem: Yemek, newItem: Yemek): Boolean {
            return oldItem == newItem
        }
    }

    inner class YemekViewHolder(private val binding: YemekItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(yemek: Yemek) {
            binding.tvYemekAdi.text = yemek.yemek_adi
            binding.tvFiyat.text = "${yemek.yemek_fiyat} ₺"
            val resimUrl = "http://kasimadalan.pe.hu/yemekler/resimler/${yemek.yemek_resim_adi}"
            Glide.with(binding.root.context).load(resimUrl).into(binding.ivYemekResim)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): YemekViewHolder {
        val binding = YemekItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return YemekViewHolder(binding)
    }

    override fun onBindViewHolder(holder: YemekViewHolder, position: Int) {
        val yemek = getItem(position)
        holder.bind(yemek)  // Veriyi bağla

        holder.itemView.setOnClickListener {
            onItemClickListener?.invoke(yemek)
        }
    }

}
