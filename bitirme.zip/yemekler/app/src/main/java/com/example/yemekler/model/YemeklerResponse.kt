package com.example.yemekler.model

data class YemeklerResponse(
    val yemekler: List<Yemek>
)
