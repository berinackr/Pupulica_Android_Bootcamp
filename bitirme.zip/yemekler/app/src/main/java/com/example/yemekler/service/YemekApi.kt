package com.example.yemekler.service

import com.example.yemekler.model.YemeklerResponse
import com.example.yemekler.model.SepetYemeklerResponse
import retrofit2.Call
import retrofit2.http.*

interface YemekApi {

    @GET("yemekler/tumYemekleriGetir.php")
    fun tumYemekleriGetir(): Call<YemeklerResponse>

    @FormUrlEncoded
    @POST("yemekler/sepettekiYemekleriGetir.php")
    fun sepettekiYemekleriGetir(
        @Field("kullanici_adi") kullanici_adi: String
    ): Call<SepetYemeklerResponse>

    @FormUrlEncoded
    @POST("yemekler/sepeteYemekEkle.php")
    fun sepeteYemekEkle(
        @Field("yemek_adi") yemek_adi: String,
        @Field("yemek_resim_adi") yemek_resim_adi: String,
        @Field("yemek_fiyat") yemek_fiyat: String,
        @Field("yemek_siparis_adet") yemek_siparis_adet: Int,
        @Field("kullanici_adi") kullanici_adi: String
    ): Call<Void>

    @FormUrlEncoded
    @POST("yemekler/sepettenYemekSil.php")
    fun sepettenYemekSil(
        @Field("sepet_yemek_id") sepet_yemek_id: Int,
        @Field("kullanici_adi") kullanici_adi: String
    ): Call<Void>
}
