package com.example.yemekler.view

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.yemekler.databinding.ActivityYemekDetayBinding
import com.example.yemekler.model.Yemek
import com.example.yemekler.viewmodel.YemekDetayViewModel

class YemekDetayActivity : AppCompatActivity() {

    private lateinit var binding: ActivityYemekDetayBinding
    private val yemekDetayViewModel: YemekDetayViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityYemekDetayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val yemekAdi = intent.getStringExtra("yemek_adi")
        val yemekFiyat = intent.getStringExtra("yemek_fiyat")
        val yemekResimAdi = intent.getStringExtra("yemek_resim_adi")

        binding.tvDetayYemekAdi.text = yemekAdi
        binding.tvDetayFiyat.text = "$yemekFiyat ₺"
        val resimUrl = "http://kasimadalan.pe.hu/yemekler/resimler/$yemekResimAdi"
        Glide.with(this).load(resimUrl).into(binding.ivDetayYemek)

        binding.btnSepeteEkle.setOnClickListener {
            // Sepete ekleme işlemi
            val yemekAdi = intent.getStringExtra("yemek_adi") ?: return@setOnClickListener
            val yemekFiyat = intent.getStringExtra("yemek_fiyat") ?: return@setOnClickListener
            val yemekResimAdi = intent.getStringExtra("yemek_resim_adi") ?: return@setOnClickListener

            // ViewModel'e gönderilecek
            yemekDetayViewModel.sepeteEkle(
                Yemek(
                    yemek_id = 0,
                    yemek_adi = yemekAdi,
                    yemek_resim_adi = yemekResimAdi,
                    yemek_fiyat = yemekFiyat
                )
            )
            Toast.makeText(this, "Sepete eklendi", Toast.LENGTH_SHORT).show()
        }

    }

}
