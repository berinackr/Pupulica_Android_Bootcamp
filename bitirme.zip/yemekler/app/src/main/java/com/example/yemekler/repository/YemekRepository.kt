package com.example.yemekler.repository

import com.example.yemekler.model.YemeklerResponse
import com.example.yemekler.model.SepetYemeklerResponse
import com.example.yemekler.service.RetrofitClient
import retrofit2.Call

class YemekRepository {

    fun tumYemekleriGetir(): Call<YemeklerResponse> {
        return RetrofitClient.api.tumYemekleriGetir()
    }

    fun sepettekiYemekleriGetir(kullanici_adi: String): Call<SepetYemeklerResponse> {
        return RetrofitClient.api.sepettekiYemekleriGetir(kullanici_adi)
    }

    fun sepeteYemekEkle(
        yemek_adi: String,
        yemek_resim_adi: String,
        yemek_fiyat: String,
        yemek_siparis_adet: Int,
        kullanici_adi: String
    ): Call<Void> {
        return RetrofitClient.api.sepeteYemekEkle(yemek_adi, yemek_resim_adi, yemek_fiyat, yemek_siparis_adet, kullanici_adi)
    }

    fun sepettenYemekSil(sepet_yemek_id: Int, kullanici_adi: String): Call<Void> {
        return RetrofitClient.api.sepettenYemekSil(sepet_yemek_id, kullanici_adi)
    }
}
