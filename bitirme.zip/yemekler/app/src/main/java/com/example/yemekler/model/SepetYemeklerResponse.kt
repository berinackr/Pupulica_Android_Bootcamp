package com.example.yemekler.model

data class SepetYemeklerResponse(
    val sepet_yemekler: List<SepetYemek>
)
